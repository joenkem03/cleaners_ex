package com.example.hp.cleaners;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;

public class PestActivity extends AppCompatActivity {

    private long lastClickTime = 0;
    private DatePicker datePicker;
    private Calendar calendar;
    private EditText servSchedule;
    private int year, month, day;
    private EditText foundLocation;
    private static final int REQUEST_LOCATION = 1;
    private LocationManager mLocationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pest);

        /*
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        */

//        ArrayList<String> myList = getIntent().getStringArrayListExtra("serviceProviders");
//
//        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
//                PestActivity.this);
//
//        alertDialog.setPositiveButton("Continue", null);
//
//        //alertDialog.setNegativeButton("No", null);
//
//        alertDialog.setMessage("We found "+myList.size()+" of our service providers that can give you the best of this server, " +
//                "please select any one of your choice from the list");
//        alertDialog.setTitle(" ");
//        alertDialog.show();
//
//        String[] myListArray = new String[myList.size()];
//        myListArray = myList.toArray(myListArray);
//        final Spinner mySpinner = findViewById(R.id.facilitySelect);
//        // Create an ArrayAdapter using the string array and a default spinner layout
//        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_spinner_item, myListArray);
//        //ArrayAdapter<CharSequence> spinnerArrayAdapter = ArrayAdapter.createFromResource(this,
//          //      R.array.services_array, android.R.layout.simple_spinner_item);
//        // Specify the layout to use when the list of choices appears
//        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        // Apply the adapter to the spinner
//        mySpinner.setAdapter(spinnerArrayAdapter);


        //final  String serviceProviders = mySpinner.getSelectedItem().toString();

        servSchedule = findViewById(R.id.date);
        foundLocation = findViewById(R.id.address);

        final String serviceFacility = getIntent().getStringExtra("serviceFacility");
        final String reqService = getIntent().getStringExtra("reqService");
        //final String serviceAmount = getIntent().getStringExtra("serviceAmount");
        final String facilitySize = getIntent().getStringExtra("facilitySize");
        //final String serviceProviders = getIntent().getStringExtra("serviceProviders");
        //final String serviceProvidersL = getIntent().getStringExtra("serviceProvidersL");

        //TextView textView = findViewById(R.id.textView);
        //textView.setText(serviceProvidersL);



        Button sendButton = findViewById(R.id.sendButton);

        sendButton.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {

//                        final String serviceProvidersSelect = mySpinner.getSelectedItem().toString();
                        final String serviceProvidersSelect = " ";

                        EditText selectDate = findViewById(R.id.date);
                        final String schedule = selectDate.getText().toString();

                        EditText facilityName = findViewById(R.id.facilityName);
                        final String facName = facilityName.getText().toString();

                        EditText facilityAddress = findViewById(R.id.address);
                        final String facAddress = facilityAddress.getText().toString();

                        EditText cName = findViewById(R.id.name);
                        final String contactName = cName.getText().toString();

                        EditText u_phone = findViewById(R.id.phone);
                        final String phone = u_phone.getText().toString();

                        EditText u_mail = findViewById(R.id.emailAddress);
                        final String email = u_mail.getText().toString();

                        if(serviceProvidersSelect == null || serviceProvidersSelect.length() == 0 ||schedule == null
                                || schedule.length() == 0 || facName == null || facName.length() == 0
                                || facAddress == null || facAddress.length() == 0 || contactName == null
                                || contactName.length() == 0 || phone == null || phone.length() == 0 ||
                                email == null || email.length() == 0){
                            Toast.makeText(getApplicationContext(), "field missing", Toast.LENGTH_LONG).show();
                            return;
                        }

                        // Invoke RESTful Web Service with Http parameters
                        //call_POST(params, url_req, email, password);
                        if(Validate.isEmailValid(email)) {

                            // preventing double, using threshold of 10000 ms
                            if (SystemClock.elapsedRealtime() - lastClickTime < 10000) {
                                return;
                            }

                            lastClickTime = SystemClock.elapsedRealtime();

                        runPost(facName, facAddress, contactName, phone, email, schedule, serviceFacility, reqService, facilitySize, serviceProvidersSelect);
                        }else {
                            Toast.makeText(getApplicationContext(), "Email not valid", Toast.LENGTH_LONG).show();
                            return;
                        }


                    }
                }
        );
    }


    @SuppressWarnings("deprecation")
    public void setAddress(View view) {

        mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if(!mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            noGpsAlertMessage();
        }
        else  if(mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            getLocation();
        }

    }

    private void getLocation() {
        if(ActivityCompat.checkSelfPermission(PestActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                (PestActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(PestActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location location = mLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            if(location != null) {
                double lat = location.getLatitude();
                double lng = location.getLongitude();
                String lattitude = String.valueOf(lat);
                String longitude = String.valueOf(lng);

                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> addressLists = null;
                try {
                    addressLists = geocoder.getFromLocation(lat, lng, 1);

                    //String[] addressArray = new String[addressList.size()];
                    //addressArray = addressList.toArray(addressArray);
                    Address addressList = addressLists.get(0);
                    ArrayList<String> addressFound = new ArrayList<String>();

                    // Fetch the address lines using getAddressLine,
                    // join them, and send them to the thread.
                    for(int i = 0; i <= addressList.getMaxAddressLineIndex(); i++) {
                        addressFound.add(addressList.getAddressLine(i));
                    }

                    //foundLocation.setText(lattitude+","+longitude);
                    foundLocation.setText(TextUtils.join(System.getProperty("line.separator"), addressFound));
                    foundLocation.setFocusableInTouchMode(true);
                    foundLocation.setFocusable(true);
                } catch (IOException e) {
                    Toast.makeText(this, "Your location not found, please enter your address", Toast.LENGTH_LONG).show();
                    foundLocation.setFocusableInTouchMode(true);
                    foundLocation.setFocusable(true);
                    //e.printStackTrace();
                }
            } else{
                Toast.makeText(this, "Your location not found, please enter your address", Toast.LENGTH_LONG).show();
                foundLocation.setFocusableInTouchMode(true);
                foundLocation.setFocusable(true);
            }

        }
    }

    private void noGpsAlertMessage() {
        android.app.AlertDialog.Builder alertBuild = new android.app.AlertDialog.Builder(this);
        alertBuild.setMessage("Please Turn ON")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
        android.app.AlertDialog alertDialog = alertBuild.create();
        alertDialog.show();
    }


    @SuppressWarnings("deprecation")
    public void setDate(View view) {

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month+1, day);

        showDialog(999);
        Toast.makeText(getApplicationContext(), "ca",
                Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker arg0,
                                      int arg1, int arg2, int arg3) {
                    // TODO Auto-generated method stub
                    // arg1 = year
                    // arg2 = month
                    // arg3 = day
                    showDate(arg1, arg2 + 1, arg3);
                }
            };

    private void showDate(int year, int month, int day) {
        //servSchedule.setText(new StringBuilder().append(day).append("/").append(month).append("/").append(year));
        servSchedule.setText(new StringBuilder().append(year).append("-").append(month).append("-").append(day));
    }


    private void runPost(String facName, String facAddress, String contactName, String phone, String email, String schedule, String serviceFacility, String reqService, String facilitySize, String serviceProviders) {

        String url_req = "bookService.json";
        String cleanType = "";


        // Instantiate Http Request Param Object
        RequestParams params = new RequestParams();
        // When Name Edit View, Email Edit View and Password Edit View have values other than Null

        // Put Http parameter username with value of Email Edit View control
        params.put("facilityName", facName);
        params.put("facilityAddress", facAddress);
        params.put("contactPerson", contactName);
        params.put("serviceSchedule", schedule);
        params.put("email", email);
        params.put("phone", phone);
        params.put("cleanType", cleanType);
        params.put("serviceFacility", serviceFacility);
        params.put("reqService", reqService);
        //params.put("serviceAmount", serviceAmount);
        params.put("facilitySize", facilitySize);
        params.put("serviceProviders", serviceProviders);

        PostConnection.POST(params, url_req, new JsonHttpResponseHandler() {

            @Override
            public void onStart() {
                // called before request is started

                Toast.makeText(getApplicationContext(), "Sending", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                //super.onSuccess(statusCode, headers, response);
                if (statusCode == 200) {

                    Toast.makeText(getApplication(), "OK", Toast.LENGTH_LONG).show();

                    String b_serviceFacility = null, b_reqService = null, b_serviceAmount = null, b_facilitySize = null, b_amount = null;
                    String b_phone = null, b_email = null, b_person = null, b_fName = null, b_fAddress = null, b_schedule = null, b_serviceId = null, b_payAdvise = null;
                    //String user_igr = null, user_mda = null, user_id = null, user_role = null, user_access = null;
                    //String yesterday_collection = "0", thismonth_collection = "0", today_collection = "0", lastmonth_collection = "0";
                    try {
                        b_serviceFacility = response.getString("serviceFacility");
                        b_reqService = response.getString("reqService");
                        b_serviceAmount = response.getString("serviceAmount");
                        b_facilitySize = response.getString("facilitySize");
                        b_phone = response.getString("phone");
                        b_email = response.getString("email");
                        b_person = response.getString("contact");
                        b_fName = response.getString("facilityName");
                        b_fAddress = response.getString("facilityAddress");
                        b_schedule = response.getString("serviceSchedule");
                        b_serviceId = response.getString("serviceBooking");
                        b_payAdvise = response.getString("payAdvise");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    //Toast.makeText(getApplicationContext(), "OK "+lastmonth_collection+"...."+mda_name, Toast.LENGTH_LONG).show();


                    Intent myIntent = new Intent(PestActivity.this, BookingActivity.class);
                    myIntent.putExtra("serviceFacility", b_serviceFacility);
                    myIntent.putExtra("reqService", b_reqService);
                    myIntent.putExtra("serviceAmount", b_serviceAmount);
                    myIntent.putExtra("facilitySize", b_facilitySize);
                    myIntent.putExtra("phone", b_phone);
                    myIntent.putExtra("email", b_email);
                    myIntent.putExtra("fLocation", b_fAddress);
                    myIntent.putExtra("Property", b_fName);
                    myIntent.putExtra("paymentAdvise", b_payAdvise);
                    myIntent.putExtra("serviceBookId", b_serviceId);
                    myIntent.putExtra("serviceScheduleDate", b_schedule);
                    myIntent.putExtra("serviceContact", b_person);

                    PestActivity.this.startActivity(myIntent);

                }
            }


            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                // called when response HTTP status is "4XX" (eg. 401, 403, 404)

                try {
                    if (statusCode == 404) {
                        Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();
                    }
                    // When Http response code is '500'
                    else if (statusCode == 500) {
                        Toast.makeText(getApplicationContext(), "Something went wrong at server end", Toast.LENGTH_LONG).show();
                    }
                    // When Http response code other than 404, 500
                    else {
                        Toast.makeText(getApplicationContext(), responseString, Toast.LENGTH_LONG).show();
                    }
                } catch (Throwable throwable1) {
                    throwable.printStackTrace();
                }


            }

            @Override
            public void onRetry(int retryNo) {
                // called when request is retried
            }

        });
    }

}
